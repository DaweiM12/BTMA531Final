library(rvest)
library(dplyr)
library(tidyr)
library(e1071)


#PKMN Statistics Table
link <- "https://pokemondb.net/pokedex/all"
page <- read_html(link)

title <- page %>% html_nodes(".sortwrap") %>% html_text()

PKMN_No <- page %>% html_nodes(".infocard-cell-data") %>% html_text() %>% as.numeric()

Name <- page %>% html_nodes(".cell-name") %>% html_text()
Name <- gsub("([a-z])([A-Z])","\\1 \\2",Name)

type <- page %>% html_nodes(".cell-icon") %>% html_text()
type <- gsub("([a-z])([A-Z])","\\1 \\2",type)

total_rate <- page %>% html_nodes(".cell-total") %>% html_text() %>% as.numeric()

HP <- page %>% html_nodes(".cell-total+ .cell-num") %>% html_text() %>% as.numeric()

Attack <- page %>% html_nodes(".cell-num:nth-child(6)") %>% html_text() %>% as.numeric()

Defense <-page %>% html_nodes(".cell-num:nth-child(7)") %>% html_text() %>% as.numeric()

Sp.Atk <- page %>% html_nodes(".cell-num:nth-child(8)") %>% html_text() %>% as.numeric()

Sp.Def <- page %>% html_nodes(".cell-num:nth-child(9)") %>% html_text() %>% as.numeric()

Speed <-  page %>% html_nodes(".cell-num:nth-child(10)") %>% html_text() %>% as.numeric()

PKMN_STAT <- data.frame(PKMN_No, Name, type, total_rate, HP, Attack, Defense, Sp.Atk, Sp.Def, Speed)
names(PKMN_STAT) <- title
PKMN_STAT <- PKMN_STAT %>% separate(Type, c("type_1", "type_2"), " ")

#Cleaning data for SVM
PKMN_STAT[,3] <- as.factor(PKMN_STAT[,3])
sampleNumbers <- sample(1:nrow(PKMN_STAT),ceiling(nrow(PKMN_STAT)/2), replace = FALSE)
PKMN_STAT_TrainSubset <- data.frame("type" = PKMN_STAT[sampleNumbers,3],scale(PKMN_STAT[sampleNumbers,6:11]))
PKMN_STAT_TestSubset <- data.frame("type" = PKMN_STAT[-sampleNumbers,3],scale(PKMN_STAT[-sampleNumbers,6:11]))

m <- svm(PKMN_STAT_TrainSubset$type ~ ., data=PKMN_STAT_TrainSubset)
m

plot(formula = m, x = PKMN_STAT_TrainSubset)

PKMN_STAT_TEST_RESULTS <- predict(m, PKMN_STAT_TestSubset)
mean(PKMN_STAT_TEST_RESULTS == PKMN_STAT_TestSubset$type)



